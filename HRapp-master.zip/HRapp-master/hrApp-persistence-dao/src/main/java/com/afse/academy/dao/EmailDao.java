package com.afse.academy.dao;

import com.afse.academy.persistence.entities.Email;

public interface EmailDao {
    void createEmail(Email email);
}
